create function st_dwithin(geog1 geography, geog2 geography, tolerance double precision, use_spheroid boolean DEFAULT true) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(&&) _ST_Expand($2,$3) AND $2 OPERATOR(&&) _ST_Expand($1,$3) AND _ST_DWithin($1, $2, $3, $4)
$$;

alter function st_dwithin(geography, geography, double precision, boolean) owner to postgres;

