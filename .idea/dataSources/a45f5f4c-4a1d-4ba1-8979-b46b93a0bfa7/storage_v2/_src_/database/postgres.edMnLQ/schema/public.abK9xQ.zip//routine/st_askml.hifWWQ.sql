create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_AsKML($1::geometry, 15);
$$;

alter function st_askml(text) owner to postgres;

