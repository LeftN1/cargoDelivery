create function dropgeometrytable(table_name character varying) returns text
    strict
    language sql
as
$$
SELECT DropGeometryTable('','',$1)
$$;

alter function dropgeometrytable(varchar) owner to postgres;

