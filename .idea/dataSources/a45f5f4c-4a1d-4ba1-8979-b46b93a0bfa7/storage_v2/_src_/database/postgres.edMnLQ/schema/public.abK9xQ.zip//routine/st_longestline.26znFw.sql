create function st_longestline(geom1 geometry, geom2 geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT _ST_LongestLine(ST_ConvexHull($1), ST_ConvexHull($2))
$$;

alter function st_longestline(geometry, geometry) owner to postgres;

