create function st_buffer(geom geometry, radius double precision, quadsegs integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_Buffer($1, $2, CAST('quad_segs='||CAST($3 AS text) as text))
$$;

alter function st_buffer(geometry, double precision, integer) owner to postgres;

