create function st_coveredby(geog1 geography, geog2 geography) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(&&) $2 AND _ST_Covers($2, $1)
$$;

alter function st_coveredby(geography, geography) owner to postgres;

