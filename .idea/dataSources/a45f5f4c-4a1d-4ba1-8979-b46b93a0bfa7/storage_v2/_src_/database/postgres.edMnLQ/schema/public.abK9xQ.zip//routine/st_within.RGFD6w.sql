create function st_within(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $2 OPERATOR(~) $1 AND _ST_Contains($2,$1)
$$;

alter function st_within(geometry, geometry) owner to postgres;

