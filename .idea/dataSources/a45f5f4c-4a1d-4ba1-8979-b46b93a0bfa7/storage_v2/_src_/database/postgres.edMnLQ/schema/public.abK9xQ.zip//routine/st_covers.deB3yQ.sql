create function st_covers(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(~) $2 AND _ST_Covers($1,$2)
$$;

alter function st_covers(geometry, geometry) owner to postgres;

