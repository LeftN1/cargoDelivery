create function st_polygon(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_SetSRID(ST_MakePolygon($1), $2)

$$;

alter function st_polygon(geometry, integer) owner to postgres;

