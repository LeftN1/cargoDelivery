create function st_angle(line1 geometry, line2 geometry) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT ST_Angle(St_StartPoint($1), ST_EndPoint($1), St_StartPoint($2), ST_EndPoint($2))
$$;

alter function st_angle(geometry, geometry) owner to postgres;

