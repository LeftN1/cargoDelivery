create function checkauth(text, text) returns integer
    language sql
as
$$
SELECT CheckAuth('', $1, $2)
$$;

alter function checkauth(text, text) owner to postgres;

