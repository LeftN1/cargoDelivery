create function st_forcepolygonccw(geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_Reverse(ST_ForcePolygonCW($1))
$$;

alter function st_forcepolygonccw(geometry) owner to postgres;

