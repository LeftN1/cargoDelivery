create function lockrow(text, text, text, timestamp without time zone) returns integer
    strict
    language sql
as
$$
SELECT LockRow(current_schema(), $1, $2, $3, $4);
$$;

alter function lockrow(text, text, text, timestamp) owner to postgres;

