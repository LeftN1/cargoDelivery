create function st_intersects(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(&&) $2 AND _ST_Intersects($1,$2)
$$;

alter function st_intersects(geometry, geometry) owner to postgres;

