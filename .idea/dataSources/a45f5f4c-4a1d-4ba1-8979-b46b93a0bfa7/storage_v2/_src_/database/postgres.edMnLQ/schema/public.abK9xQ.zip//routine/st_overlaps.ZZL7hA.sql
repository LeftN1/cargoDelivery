create function st_overlaps(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(&&) $2 AND _ST_Overlaps($1,$2)
$$;

alter function st_overlaps(geometry, geometry) owner to postgres;

