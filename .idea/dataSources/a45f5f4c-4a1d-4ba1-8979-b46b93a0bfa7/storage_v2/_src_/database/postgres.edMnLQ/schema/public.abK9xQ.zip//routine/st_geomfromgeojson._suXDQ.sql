create function st_geomfromgeojson(jsonb) returns geometry
    immutable
    strict
    parallel safe
    cost 10
    language sql
as
$$
SELECT ST_GeomFromGeoJson($1::text)
$$;

alter function st_geomfromgeojson(jsonb) owner to postgres;

