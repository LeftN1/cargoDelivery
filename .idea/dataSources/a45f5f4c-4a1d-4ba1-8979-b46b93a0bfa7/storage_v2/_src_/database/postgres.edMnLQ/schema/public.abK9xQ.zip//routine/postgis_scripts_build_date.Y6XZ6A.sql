create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$
SELECT '2020-08-15 21:24:03'::text AS version
$$;

alter function postgis_scripts_build_date() owner to postgres;

