create function st_asgeojson(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_AsGeoJson($1::geometry, 9, 0);
$$;

alter function st_asgeojson(text) owner to postgres;

