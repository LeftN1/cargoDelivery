create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_Distance($1::geometry, $2::geometry);
$$;

alter function st_distance(text, text) owner to postgres;

