create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT ST_CoveredBy($1::geometry, $2::geometry);
$$;

alter function st_coveredby(text, text) owner to postgres;

