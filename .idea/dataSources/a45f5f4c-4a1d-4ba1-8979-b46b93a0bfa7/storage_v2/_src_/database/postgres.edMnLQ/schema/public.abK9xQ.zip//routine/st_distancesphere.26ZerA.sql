create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
select ST_distance( geography($1), geography($2),false)
$$;

alter function st_distancesphere(geometry, geometry) owner to postgres;

