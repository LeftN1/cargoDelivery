create function st_geomfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    parallel safe
    cost 10
    language sql
as
$$
SELECT CAST(ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;

alter function st_geomfromgeohash(text, integer) owner to postgres;

