create function st_linestringfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_linestringfromwkb(bytea) owner to postgres;

