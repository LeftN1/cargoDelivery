create function st_intersects(geography, geography) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(&&) $2 AND ST_Distance($1, $2, false) < 0.00001
$$;

alter function st_intersects(geography, geography) owner to postgres;

