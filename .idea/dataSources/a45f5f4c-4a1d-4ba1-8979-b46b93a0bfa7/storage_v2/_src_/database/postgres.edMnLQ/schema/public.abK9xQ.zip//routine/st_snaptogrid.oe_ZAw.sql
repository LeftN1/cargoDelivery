create function st_snaptogrid(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_SnapToGrid($1, 0, 0, $2, $2)
$$;

alter function st_snaptogrid(geometry, double precision) owner to postgres;

