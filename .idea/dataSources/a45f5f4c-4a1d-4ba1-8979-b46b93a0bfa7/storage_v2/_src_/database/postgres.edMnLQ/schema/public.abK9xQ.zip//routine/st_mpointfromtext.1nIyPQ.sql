create function st_mpointfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

alter function st_mpointfromtext(text, integer) owner to postgres;

